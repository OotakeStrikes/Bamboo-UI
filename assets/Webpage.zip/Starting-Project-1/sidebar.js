class Sidebar {
    constructor(id, side, onDragEnd) {
        this.id = id;
        this.side = side;
        this.onDragEnd = onDragEnd;

        this.element = document.createElement('div');
        this.element.className = 'sidebar';
        this.element.id = `sidebar-${id}`;

        this.topBar = document.createElement('div');
        this.topBar.className = 'top-bar';
        this.topBar.textContent = `Tab ${id}`;
        this.element.appendChild(this.topBar);

        this.content = document.createElement('div');
        this.content.className = 'content';
        this.content.textContent = `Content for Tab ${id}`;
        this.element.appendChild(this.content);

        // Make the top bar draggable
        this.topBar.draggable = true;

        this.topBar.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text', this.id);
            // Create a custom drag image to prevent blurriness and maintain size
            const dragImage = this.element.cloneNode(true);
            dragImage.style.position = 'absolute';
            dragImage.style.top = '-9999px';
            dragImage.style.width = this.element.offsetWidth + 'px'; // Maintain original width
            dragImage.style.height = this.element.offsetHeight + 'px'; // Maintain original height
            dragImage.style.filter = 'none !important'; // Explicitly remove blur
            dragImage.style.overflow = 'hidden'; // Prevent capturing external content
            document.body.appendChild(dragImage);
            e.dataTransfer.setDragImage(dragImage, 0, 0);

            setTimeout(() => {
                this.element.style.display = 'none';
                render(); // Re-render to adjust remaining sidebars
            }, 0);
        });

        this.topBar.addEventListener('dragend', () => {
            this.element.style.display = '';
            render();
        });

        // Add spawn animation
        setTimeout(() => {
            this.element.classList.add('visible');
        }, 0);
    }

    setSide(newSide) {
        this.side = newSide;
    }
}