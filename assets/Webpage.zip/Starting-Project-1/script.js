const container = document.querySelector('.container');
let leftSidebars = [];
let rightSidebars = [];
const mainScreen = new MainScreen(() => addSidebar('left'));
let previewElement = null;

function createPreviewElement(sidebar) {
    const preview = sidebar.element.cloneNode(true);
    preview.className = 'sidebar-preview';
    preview.style.display = 'block';
    preview.style.width = sidebar.element.offsetWidth + 'px'; // Maintain original width
    preview.style.height = sidebar.element.offsetHeight + 'px'; // Maintain original height
    preview.style.filter = 'none !important'; // Explicitly remove blur
    preview.style.overflow = 'hidden'; // Prevent capturing external content
    return preview;
}

function render() {
    container.innerHTML = '';

    const visibleLeftSidebars = leftSidebars.filter(s => s.element.style.display !== 'none');
    const visibleRightSidebars = rightSidebars.filter(s => s.element.style.display !== 'none');

    let availableWidth = 100;
    if (visibleLeftSidebars.length > 0) availableWidth -= 20;
    if (visibleRightSidebars.length > 0) availableWidth -= 20;

    const mainScreenWidth = availableWidth * 0.9;

    if (visibleLeftSidebars.length === 0 && visibleRightSidebars.length === 0) {
        mainScreen.element.style.width = '70%';
        mainScreen.element.style.top = 'unset';
        mainScreen.element.style.height = '60%';
        container.appendChild(mainScreen.element);
    } else {
        if (visibleLeftSidebars.length > 0) {
            const leftDiv = document.createElement('div');
            leftDiv.className = 'left-sidebars';
            leftDiv.style.width = '20%';
            visibleLeftSidebars.forEach(s => {
                s.element.style.width = '100%';
                s.element.style.height = `${100 / visibleLeftSidebars.length}%`;
                leftDiv.appendChild(s.element);
            });
            container.appendChild(leftDiv);
        }

        mainScreen.element.style.width = '49%';
        mainScreen.element.style.height = '60%';
        mainScreen.element.style.top = 'unset';
        container.appendChild(mainScreen.element);

        if (visibleRightSidebars.length > 0) {
            const rightDiv = document.createElement('div');
            rightDiv.className = 'right-sidebars';
            rightDiv.style.width = '20%';
            visibleRightSidebars.forEach(s => {
                s.element.style.width = '100%';
                s.element.style.height = `${100 / visibleRightSidebars.length}%`;
                rightDiv.appendChild(s.element);
            });
            container.appendChild(rightDiv);
        }
    }
}

function addSidebar(side = 'left') {
    const id = (leftSidebars.length + rightSidebars.length + 1).toString();
    const sidebar = new Sidebar(id, side, handleDragEnd);
    if (side === 'left') {
        leftSidebars.push(sidebar);
    } else {
        rightSidebars.push(sidebar);
    }
    render();
}

function handleDragEnd(draggedSidebar) {
    // Clean up preview
    if (previewElement) {
        previewElement.remove();
        previewElement = null;
    }
}

container.addEventListener('dragover', (e) => {
    e.preventDefault();

    const id = e.dataTransfer.getData('text');
    const draggedSidebar = leftSidebars.find(s => s.id === id) || rightSidebars.find(s => s.id === id);

    if (!draggedSidebar) return;

    const containerRect = container.getBoundingClientRect();
    const dropX = e.clientX - containerRect.left;
    const dropY = e.clientY - containerRect.top;

    const newSide = dropX < containerRect.width / 2 ? 'left' : 'right';
    const toArray = newSide === 'left' ? leftSidebars : rightSidebars;
    const visibleToArray = toArray.filter(s => s.element.style.display !== 'none');

    // Create or update preview element
    if (!previewElement) {
        previewElement = createPreviewElement(draggedSidebar);
        document.body.appendChild(previewElement);
    }

    // Position the preview
    previewElement.style.left = newSide === 'left' ? '0' : `${containerRect.width - previewElement.offsetWidth}px`;

    // Calculate insertion index and position
    let insertIndex = visibleToArray.length;
    let previewTop = containerRect.height * 0.2; // Start at top: 20%
    for (let i = 0; i < visibleToArray.length; i++) {
        const rect = visibleToArray[i].element.getBoundingClientRect();
        if (dropY < (rect.top - containerRect.top) + rect.height / 2) {
            insertIndex = i;
            break;
        }
        previewTop += rect.height;
    }

    // Adjust preview position
    const topPosition = containerRect.top + (containerRect.height * 0.2) + (insertIndex * draggedSidebar.element.offsetHeight);
    previewElement.style.top = `${topPosition}px`;

    // Slide visible sidebars
    visibleToArray.forEach((s, index) => {
        if (index < insertIndex) {
            s.element.style.transform = 'translateY(0)';
        } else {
            s.element.style.transform = `translateY(${draggedSidebar.element.offsetHeight}px)`;
        }
    });
});

container.addEventListener('drop', (e) => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text');
    let draggedSidebar;
    let fromArray;

    if (leftSidebars.find(s => s.id === id)) {
        fromArray = leftSidebars;
    } else {
        fromArray = rightSidebars;
    }
    draggedSidebar = fromArray.find(s => s.id === id);

    if (draggedSidebar) {
        const containerRect = container.getBoundingClientRect();
        const dropX = e.clientX - containerRect.left;
        const dropY = e.clientY - containerRect.top;
        const newSide = dropX < containerRect.width / 2 ? 'left' : 'right';
        const toArray = newSide === 'left' ? leftSidebars : rightSidebars;

        fromArray.splice(fromArray.indexOf(draggedSidebar), 1);

        let insertIndex = toArray.length;
        for (let i = 0; i < toArray.length; i++) {
            const rect = toArray[i].element.getBoundingClientRect();
            if (dropY < (rect.top - containerRect.top) + rect.height / 2) {
                insertIndex = i;
                break;
            }
        }

        toArray.splice(insertIndex, 0, draggedSidebar);
        draggedSidebar.setSide(newSide);

        draggedSidebar.element.style.display = '';
        toArray.forEach(s => s.element.style.transform = '');

        // Clean up preview
        if (previewElement) {
            previewElement.remove();
            previewElement = null;
        }

        render();
    }
});

render();