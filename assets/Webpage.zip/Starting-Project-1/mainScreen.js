class MainScreen {
    constructor(onAddSidebar) {
        this.element = document.createElement('div');
        this.element.className = 'main-screen';
        this.element.innerHTML = '<button>Add Sidebar</button>';
        this.element.querySelector('button').addEventListener('click', onAddSidebar);
    }
}